#!/usr/local/bin/perl

print "Content-type: text/html", "\n\n";

print "<HTML>", "\n";
print "<HEAD><TITLE>Simple Virtual HTML Document</TITLE></HEAD>", "\n";
print "<BODY>", "\n";
print "<H1>", "Virtual HTML", "</H1>", "<HR>", "\n";
print "Hey look, I just created a virtual (yep, virtual) HTML document!", "\n";
print "</BODY></HTML>", "\n";

exit (0);
